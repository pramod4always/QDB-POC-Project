INSERT INTO documents VALUES (1, 'D001', 'C:/uploads', '2022-04-14', '', '');
INSERT INTO documents VALUES (2, 'D001', 'C:/uploads', '2022-04-14', '', '');
INSERT INTO documents VALUES (3, 'D001', 'C:/uploads', '2022-04-14', '', '');
INSERT INTO documents VALUES (4, 'D001', 'C:/uploads', '2022-04-14', '', '');